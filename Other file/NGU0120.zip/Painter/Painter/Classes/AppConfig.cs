﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Painter.Classes
{
	public class AppConfig
	{
		public string Title { get; set; }
		public int Width { get; set; }
		public int Height { get; set; }
		public string About { get; set; }
	}
}
