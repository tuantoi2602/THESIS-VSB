function Error() {
    return <h1 style={{ color: 'black', marginTop: 60, display: 'flex', justifyContent: 'center' }}>404 Error</h1>;
}

export default Error;
